import http.server
import socketserver
import json
import os
import threading
from urllib.parse import unquote

PORT = 8000
STATUS_FILE = 'status.json'
# Now only 3 devices are needed
DEVICE_COUNT = 3

# Lock for thread-safe file access
file_lock = threading.Lock()

def create_status_file():
    """Initializes or resets the status.json file for 3 devices."""
    initial_status = {f"device_{i+1}": False for i in range(DEVICE_COUNT)}
    
    with file_lock:
        with open(STATUS_FILE, 'w') as f:
            json.dump(initial_status, f, indent=4)

class MyHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith('/status'):
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            with file_lock:
                with open(STATUS_FILE, 'r') as f:
                    status_data = json.load(f)
            self.wfile.write(json.dumps(status_data).encode())
        else:
            super().do_GET()

    def do_POST(self):
        if self.path.startswith('/authenticate/'):
            # The device ID will be a simple number now
            device_id = unquote(self.path.split('/')[-1])
            
            is_valid_device = False
            with file_lock:
                with open(STATUS_FILE, 'r') as f:
                    status_data = json.load(f)
                    if device_id in status_data:
                        is_valid_device = True

            if is_valid_device:
                content_length = int(self.headers['Content-Length'])
                post_data = self.rfile.read(content_length)
                auth_status = json.loads(post_data.decode('utf-8'))
                
                with file_lock:
                    with open(STATUS_FILE, 'r+') as f:
                        status_data = json.load(f)
                        status_data[device_id] = auth_status['authenticated']
                        f.seek(0)
                        json.dump(status_data, f, indent=4)
                        f.truncate()
                
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"success": True}).encode())
            else:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(json.dumps({"success": False, "message": "Invalid device ID."}).encode())
        elif self.path == '/reset':
            create_status_file()
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"success": True, "message": "Authentication status reset."}).encode())
        else:
            self.send_response(404)
            self.end_headers()

def run_server():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    create_status_file()
    
    Handler = MyHandler
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        print(f"Server started at http://localhost:{PORT}")
        print("Point your devices to this URL on the same network.")
        httpd.serve_forever()

if __name__ == "__main__":
    run_server()